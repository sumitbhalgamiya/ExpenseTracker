﻿using ExpenseTracker.DTOs;
using ExpenseTracker.Models;
using ExpenseTracker.Repositories;
using Microsoft.AspNetCore.Identity;

namespace ExpenseTracker.Services
{
    public class UserService : IUserService
    {
        private readonly IRepository<User> _userRepository;
        private readonly IPasswordHasher<User> _passwordHasher;

        public UserService(IRepository<User> userRepository, IPasswordHasher<User> passwordHasher)
        {
            _userRepository = userRepository;
            _passwordHasher = passwordHasher;
        }

        public async Task RegisterAsync(RegisterUserDto dto)
        {
            var existingUser = await _userRepository.GetAsync(u => u.Email == dto.Email);
            if (existingUser != null)
                throw new Exception("Email already registered");

            var user = new User
            {
                FullName = dto.FullName,
                Email = dto.Email
            };

            user.PasswordHash = _passwordHasher.HashPassword(user, dto.Password);
            await _userRepository.AddAsync(user);
        }

        public async Task<User> LoginAsync(LoginUserDto dto)
        {
            var user = await _userRepository.GetAsync(u => u.Email == dto.Email);
            if (user == null)
                throw new Exception("Invalid credentials");

            var result = _passwordHasher.VerifyHashedPassword(user, user.PasswordHash, dto.Password);
            if (result == PasswordVerificationResult.Failed)
                throw new Exception("Invalid credentials");

            return user;
        }
        public async Task<User> GetByEmailAsync(string email)
        {
            return await _userRepository.GetAsync(u => u.Email == email);
        }
        public async Task<User> GetByIdAsync(int id)
        {
            return await _userRepository.GetAsync(u => u.Id == id);  // Fetch the user by ID
        }
    }
}
