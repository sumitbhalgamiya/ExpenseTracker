﻿using ExpenseTracker.DTOs;
using ExpenseTracker.Models;

namespace ExpenseTracker.Services
{
    public interface IUserService
    {
        Task RegisterAsync(RegisterUserDto dto);
        Task<User> LoginAsync(LoginUserDto dto);

        Task<User> GetByEmailAsync(string email);
        Task<User> GetByIdAsync(int id);
    }
}
