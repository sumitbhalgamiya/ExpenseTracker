﻿using ExpenseTracker.DTOs;
using ExpenseTracker.Models;
using ExpenseTracker.Repositories;

namespace ExpenseTracker.Services
{
    public class DashboardService
    {
        private readonly ExpenseRepository _expenseRepository;

        public DashboardService(ExpenseRepository expenseRepository)
        {
            _expenseRepository = expenseRepository;
        }
        public async Task<DashboardDto> GetDashboardDataByUserIdAsync(int userId)
        {
            var expenses = await _expenseRepository.GetExpensesByUserIdAsync(userId)
                            ?? new List<Expense>();

            return new DashboardDto
            {
                TotalExpenses = expenses.Sum(e => e.Amount),
                AverageExpense = expenses.Count > 0 ? expenses.Average(e => e.Amount) : 0,
                TotalTransactions = expenses.Count,
                ExpenseCategories = expenses.Select(e => e.Category ?? "Uncategorized").ToList(),
                ExpenseAmounts = expenses.Select(e => e.Amount).ToList()
            };
        }

    }

}

