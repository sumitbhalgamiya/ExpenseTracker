﻿namespace ExpenseTracker.DTOs
{
    public class DashboardDto
    {
        public decimal TotalExpenses { get; set; }
        public decimal AverageExpense { get; set; }
        public int TotalTransactions { get; set; }

        public List<string> ExpenseCategories { get; set; } = new List<string>();
        public List<decimal> ExpenseAmounts { get; set; } = new List<decimal>();
    }

}
