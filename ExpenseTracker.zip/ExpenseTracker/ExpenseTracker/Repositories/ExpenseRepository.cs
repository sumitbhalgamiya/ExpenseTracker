﻿using System.Linq.Expressions;
using ExpenseTracker.Data;
using ExpenseTracker.Models;
using Microsoft.EntityFrameworkCore;

namespace ExpenseTracker.Repositories
{
    public class ExpenseRepository : IRepository<Expense>
    {
        private readonly AppDbContext _context;

        public ExpenseRepository(AppDbContext context)
        {
            _context = context;
        }

        public async Task<Expense> GetAsync(Expression<Func<Expense, bool>> predicate)
        {
            return await _context.Expenses
                .Include(e => e.User)
                .FirstOrDefaultAsync(predicate);
        }

        public async Task<List<Expense>> GetAllAsync(Expression<Func<Expense, bool>> predicate = null)
        {
            IQueryable<Expense> query = _context.Expenses.Include(e => e.User);

            if (predicate != null)
                query = query.Where(predicate);

            return await query.ToListAsync();
        }

        public async Task AddAsync(Expense expense)
        {
            await _context.Expenses.AddAsync(expense);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateAsync(Expense expense)
        {
            _context.Expenses.Update(expense);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteAsync(Expense expense)
        {
            _context.Expenses.Remove(expense);
            await _context.SaveChangesAsync();
        }

        public async Task<List<Expense>> GetExpensesByEmailAsync(string email)
        {
            return await _context.Expenses
                .Include(e => e.User)
                .Where(e => e.User.Email == email)
                .ToListAsync();
        }
        // Optional convenience method
        public async Task<List<Expense>> GetExpensesByUserIdAsync(int userId)
        {
            return await _context.Expenses
                .Where(e => e.UserId == userId)
                .ToListAsync();
        }
    }

}
