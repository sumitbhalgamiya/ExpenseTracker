﻿using System.Security.Claims;
using ExpenseTracker.Models;
using ExpenseTracker.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace ExpenseTracker.Controllers
{
    [Authorize]
    public class ExpensesController : Controller
    {
        private readonly IExpenseService _expenseService;
        private readonly IUserService _userService;
        private readonly ILogger<HomeController> _logger;
        public ExpensesController(IExpenseService expenseService, IUserService userService)
        {
            _expenseService = expenseService;
            _userService = userService;
        }
        private async Task<User> GetLoggedInUserAsync()
        {
            // Fetch user ID from claims (NameIdentifier holds the user ID)
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);

            if (string.IsNullOrEmpty(userId))
            {
                // If no user ID found in claims, return null
                return null;
            }

            // Get user by ID from the database using your user service
            return await _userService.GetByIdAsync(int.Parse(userId));
        }

        public async Task<IActionResult> Index()
        {
            var user = await GetLoggedInUserAsync();
            if (user == null) return Unauthorized();

            var expenses = await _expenseService.GetUserExpensesAsync(user.Id);
            return View(expenses);
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Create(Expense expense)
        {
            var userIdString = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            var user = await GetLoggedInUserAsync();

            if (expense.Date == default)
                expense.Date = DateTime.Now;

            expense.UserId = user.Id;
            await _expenseService.AddExpenseAsync(expense);

            TempData["Success"] = "Expense added successfully.";
            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> Edit(int id)
        {
            var expense = await _expenseService.GetExpenseByIdAsync(id);
            if (expense == null) return NotFound();
            return View(expense);
        }

        [HttpPost]
        public async Task<IActionResult> Edit(Expense expense)
        {
            await _expenseService.UpdateExpenseAsync(expense);
            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> Delete(int id)
        {
            var expense = await _expenseService.GetExpenseByIdAsync(id);
            if (expense == null) return NotFound();
            return View(expense);
        }

        [HttpPost, ActionName("Delete")]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            await _expenseService.DeleteExpenseAsync(id);
            return RedirectToAction(nameof(Index));
        }

    }
}

